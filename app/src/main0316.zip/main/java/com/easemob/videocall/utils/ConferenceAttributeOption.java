package com.easemob.videocall.utils;

public class ConferenceAttributeOption {
    public final static String  REQUEST_TOBE_SPEAKER = "request_tobe_speaker";
    public final static String  REQUEST_TOBE_AUDIENCE = "request_tobe_audience";
    public final static String  REQUEST_BECOME_ADMIN = "become_admin";
}
